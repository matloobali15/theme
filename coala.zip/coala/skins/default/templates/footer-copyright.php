<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package COALA
 * @since COALA 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap
<?php
$coala_copyright_scheme = coala_get_theme_option( 'copyright_scheme' );
if ( ! empty( $coala_copyright_scheme ) && ! coala_is_inherit( $coala_copyright_scheme  ) ) {
	echo ' scheme_' . esc_attr( $coala_copyright_scheme );
}
?>
				">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text">
			<?php
				$coala_copyright = coala_get_theme_option( 'copyright' );
			if ( ! empty( $coala_copyright ) ) {
				// Replace {{Y}} or {Y} with the current year
				$coala_copyright = str_replace( array( '{{Y}}', '{Y}' ), date( 'Y' ), $coala_copyright );
				// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
				$coala_copyright = coala_prepare_macros( $coala_copyright );
				// Display copyright
				echo wp_kses( nl2br( $coala_copyright ), 'coala_kses_content' );
			}
			?>
			</div>
		</div>
	</div>
</div>
