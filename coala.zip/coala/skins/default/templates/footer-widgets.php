<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package COALA
 * @since COALA 1.0.10
 */

// Footer sidebar
$coala_footer_name    = coala_get_theme_option( 'footer_widgets' );
$coala_footer_present = ! coala_is_off( $coala_footer_name ) && is_active_sidebar( $coala_footer_name );
if ( $coala_footer_present ) {
	coala_storage_set( 'current_sidebar', 'footer' );
	$coala_footer_wide = coala_get_theme_option( 'footer_wide' );
	ob_start();
	if ( is_active_sidebar( $coala_footer_name ) ) {
		dynamic_sidebar( $coala_footer_name );
	}
	$coala_out = trim( ob_get_contents() );
	ob_end_clean();
	if ( ! empty( $coala_out ) ) {
		$coala_out          = preg_replace( "/<\\/aside>[\r\n\s]*<aside/", '</aside><aside', $coala_out );
		$coala_need_columns = true;   //or check: strpos($coala_out, 'columns_wrap')===false;
		if ( $coala_need_columns ) {
			$coala_columns = max( 0, (int) coala_get_theme_option( 'footer_columns' ) );			
			if ( 0 == $coala_columns ) {
				$coala_columns = min( 4, max( 1, coala_tags_count( $coala_out, 'aside' ) ) );
			}
			if ( $coala_columns > 1 ) {
				$coala_out = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $coala_columns ) . ' widget', $coala_out );
			} else {
				$coala_need_columns = false;
			}
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo ! empty( $coala_footer_wide ) ? ' footer_fullwidth' : ''; ?> sc_layouts_row sc_layouts_row_type_normal">
			<?php do_action( 'coala_action_before_sidebar_wrap', 'footer' ); ?>
			<div class="footer_widgets_inner widget_area_inner">
				<?php
				if ( ! $coala_footer_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $coala_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'coala_action_before_sidebar', 'footer' );
				coala_show_layout( $coala_out );
				do_action( 'coala_action_after_sidebar', 'footer' );
				if ( $coala_need_columns ) {
					?>
					</div><!-- /.columns_wrap -->
					<?php
				}
				if ( ! $coala_footer_wide ) {
					?>
					</div><!-- /.content_wrap -->
					<?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
			<?php do_action( 'coala_action_after_sidebar_wrap', 'footer' ); ?>
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
