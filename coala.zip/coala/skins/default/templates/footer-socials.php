<?php
/**
 * The template to display the socials in the footer
 *
 * @package COALA
 * @since COALA 1.0.10
 */


// Socials
if ( coala_is_on( coala_get_theme_option( 'socials_in_footer' ) ) ) {
	$coala_output = coala_get_socials_links();
	if ( '' != $coala_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php coala_show_layout( $coala_output ); ?>
			</div>
		</div>
		<?php
	}
}
