<?php
/**
 * 'Band' template to display the content
 *
 * Used for index/archive/search.
 *
 * @package COALA
 * @since COALA 1.71.0
 */

$coala_template_args = get_query_var( 'coala_template_args' );

$coala_columns       = 1;

$coala_expanded      = ! coala_sidebar_present() && coala_get_theme_option( 'expand_content' ) == 'expand';

$coala_post_format   = get_post_format();
$coala_post_format   = empty( $coala_post_format ) ? 'standard' : str_replace( 'post-format-', '', $coala_post_format );

if ( is_array( $coala_template_args ) ) {
	$coala_columns    = empty( $coala_template_args['columns'] ) ? 1 : max( 1, $coala_template_args['columns'] );
	$coala_blog_style = array( $coala_template_args['type'], $coala_columns );
	if ( ! empty( $coala_template_args['slider'] ) ) {
		?><div class="slider-slide swiper-slide">
		<?php
	} elseif ( $coala_columns > 1 ) {
	    $coala_columns_class = coala_get_column_class( 1, $coala_columns, ! empty( $coala_template_args['columns_tablet']) ? $coala_template_args['columns_tablet'] : '', ! empty($coala_template_args['columns_mobile']) ? $coala_template_args['columns_mobile'] : '' );
				?><div class="<?php echo esc_attr( $coala_columns_class ); ?>"><?php
	}
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class( 'post_item post_item_container post_layout_band post_format_' . esc_attr( $coala_post_format ) );
	coala_add_blog_animation( $coala_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$coala_hover      = ! empty( $coala_template_args['hover'] ) && ! coala_is_inherit( $coala_template_args['hover'] )
							? $coala_template_args['hover']
							: coala_get_theme_option( 'image_hover' );
	$coala_components = ! empty( $coala_template_args['meta_parts'] )
							? ( is_array( $coala_template_args['meta_parts'] )
								? $coala_template_args['meta_parts']
								: array_map( 'trim', explode( ',', $coala_template_args['meta_parts'] ) )
								)
							: coala_array_get_keys_by_value( coala_get_theme_option( 'meta_parts' ) );
	coala_show_post_featured( apply_filters( 'coala_filter_args_featured',
		array(
			'no_links'   => ! empty( $coala_template_args['no_links'] ),
			'hover'      => $coala_hover,
			'meta_parts' => $coala_components,
			'thumb_bg'   => true,
			'thumb_ratio'   => '1:1',
			'thumb_size' => ! empty( $coala_template_args['thumb_size'] )
								? $coala_template_args['thumb_size']
								: coala_get_thumb_size( 
								in_array( $coala_post_format, array( 'gallery', 'audio', 'video' ) )
									? ( strpos( coala_get_theme_option( 'body_style' ), 'full' ) !== false
										? 'full'
										: ( $coala_expanded 
											? 'big' 
											: 'medium-square'
											)
										)
									: 'masonry-big'
								)
		),
		'content-band',
		$coala_template_args
	) );

	?><div class="post_content_wrap"><?php

		// Title and post meta
		$coala_show_title = get_the_title() != '';
		$coala_show_meta  = count( $coala_components ) > 0 && ! in_array( $coala_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );
		if ( $coala_show_title ) {
			?>
			<div class="post_header entry-header">
				<?php
				// Categories
				if ( apply_filters( 'coala_filter_show_blog_categories', $coala_show_meta && in_array( 'categories', $coala_components ), array( 'categories' ), 'band' ) ) {
					do_action( 'coala_action_before_post_category' );
					?>
					<div class="post_category">
						<?php
						coala_show_post_meta( apply_filters(
															'coala_filter_post_meta_args',
															array(
																'components' => 'categories',
																'seo'        => false,
																'echo'       => true,
																'cat_sep'    => false,
																),
															'hover_' . $coala_hover, 1
															)
											);
						?>
					</div>
					<?php
					$coala_components = coala_array_delete_by_value( $coala_components, 'categories' );
					do_action( 'coala_action_after_post_category' );
				}
				// Post title
				if ( apply_filters( 'coala_filter_show_blog_title', true, 'band' ) ) {
					do_action( 'coala_action_before_post_title' );
					if ( empty( $coala_template_args['no_links'] ) ) {
						the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );
					} else {
						the_title( '<h4 class="post_title entry-title">', '</h4>' );
					}
					do_action( 'coala_action_after_post_title' );
				}
				?>
			</div><!-- .post_header -->
			<?php
		}

		// Post content
		if ( ! isset( $coala_template_args['excerpt_length'] ) && ! in_array( $coala_post_format, array( 'gallery', 'audio', 'video' ) ) ) {
			$coala_template_args['excerpt_length'] = 13;
		}
		if ( apply_filters( 'coala_filter_show_blog_excerpt', empty( $coala_template_args['hide_excerpt'] ) && coala_get_theme_option( 'excerpt_length' ) > 0, 'band' ) ) {
			?>
			<div class="post_content entry-content">
				<?php
				// Post content area
				coala_show_post_content( $coala_template_args, '<div class="post_content_inner">', '</div>' );
				?>
			</div><!-- .entry-content -->
			<?php
		}
		// Post meta
		if ( apply_filters( 'coala_filter_show_blog_meta', $coala_show_meta, $coala_components, 'band' ) ) {
			if ( count( $coala_components ) > 0 ) {
				do_action( 'coala_action_before_post_meta' );
				coala_show_post_meta(
					apply_filters(
						'coala_filter_post_meta_args', array(
							'components' => join( ',', $coala_components ),
							'seo'        => false,
							'echo'       => true,
						), 'band', 1
					)
				);
				do_action( 'coala_action_after_post_meta' );
			}
		}
		// More button
		if ( apply_filters( 'coala_filter_show_blog_readmore', ! $coala_show_title || ! empty( $coala_template_args['more_button'] ), 'band' ) ) {
			if ( empty( $coala_template_args['no_links'] ) ) {
				do_action( 'coala_action_before_post_readmore' );
				coala_show_post_more_link( $coala_template_args, '<div class="more-wrap">', '</div>' );
				do_action( 'coala_action_after_post_readmore' );
			}
		}
		?>
	</div>
</article>
<?php

if ( is_array( $coala_template_args ) ) {
	if ( ! empty( $coala_template_args['slider'] ) || $coala_columns > 1 ) {
		?>
		</div>
		<?php
	}
}
