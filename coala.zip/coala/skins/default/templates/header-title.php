<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package COALA
 * @since COALA 1.0
 */

// Page (category, tag, archive, author) title

if ( coala_need_page_title() ) {
	coala_sc_layouts_showed( 'title', true );
	coala_sc_layouts_showed( 'postmeta', true );
	?>
	<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Post meta on the single post
						if ( is_single() ) {
							?>
							<div class="sc_layouts_title_meta">
							<?php
								coala_show_post_meta(
									apply_filters(
										'coala_filter_post_meta_args', array(
											'components' => join( ',', coala_array_get_keys_by_value( coala_get_theme_option( 'meta_parts' ) ) ),
											'counters'   => join( ',', coala_array_get_keys_by_value( coala_get_theme_option( 'counters' ) ) ),
											'seo'        => coala_is_on( coala_get_theme_option( 'seo_snippets' ) ),
										), 'header', 1
									)
								);
							?>
							</div>
							<?php
						}

						// Blog/Post title
						?>
						<div class="sc_layouts_title_title">
							<?php
							$coala_blog_title           = coala_get_blog_title();
							$coala_blog_title_text      = '';
							$coala_blog_title_class     = '';
							$coala_blog_title_link      = '';
							$coala_blog_title_link_text = '';
							if ( is_array( $coala_blog_title ) ) {
								$coala_blog_title_text      = $coala_blog_title['text'];
								$coala_blog_title_class     = ! empty( $coala_blog_title['class'] ) ? ' ' . $coala_blog_title['class'] : '';
								$coala_blog_title_link      = ! empty( $coala_blog_title['link'] ) ? $coala_blog_title['link'] : '';
								$coala_blog_title_link_text = ! empty( $coala_blog_title['link_text'] ) ? $coala_blog_title['link_text'] : '';
							} else {
								$coala_blog_title_text = $coala_blog_title;
							}
							?>
							<h1 itemprop="headline" class="sc_layouts_title_caption<?php echo esc_attr( $coala_blog_title_class ); ?>">
								<?php
								$coala_top_icon = coala_get_term_image_small();
								if ( ! empty( $coala_top_icon ) ) {
									$coala_attr = coala_getimagesize( $coala_top_icon );
									?>
									<img src="<?php echo esc_url( $coala_top_icon ); ?>" alt="<?php esc_attr_e( 'Site icon', 'coala' ); ?>"
										<?php
										if ( ! empty( $coala_attr[3] ) ) {
											coala_show_layout( $coala_attr[3] );
										}
										?>
									>
									<?php
								}
								echo wp_kses_data( $coala_blog_title_text );
								?>
							</h1>
							<?php
							if ( ! empty( $coala_blog_title_link ) && ! empty( $coala_blog_title_link_text ) ) {
								?>
								<a href="<?php echo esc_url( $coala_blog_title_link ); ?>" class="theme_button theme_button_small sc_layouts_title_link"><?php echo esc_html( $coala_blog_title_link_text ); ?></a>
								<?php
							}

							// Category/Tag description
							if ( ! is_paged() && ( is_category() || is_tag() || is_tax() ) ) {
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
							}

							?>
						</div>
						<?php

						// Breadcrumbs
						ob_start();
						do_action( 'coala_action_breadcrumbs' );
						$coala_breadcrumbs = ob_get_contents();
						ob_end_clean();
						coala_show_layout( $coala_breadcrumbs, '<div class="sc_layouts_title_breadcrumbs">', '</div>' );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
