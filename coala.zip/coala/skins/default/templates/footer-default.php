<?php
/**
 * The template to display default site footer
 *
 * @package COALA
 * @since COALA 1.0.10
 */

?>
<footer class="footer_wrap footer_default
<?php
$coala_footer_scheme = coala_get_theme_option( 'footer_scheme' );
if ( ! empty( $coala_footer_scheme ) && ! coala_is_inherit( $coala_footer_scheme  ) ) {
	echo ' scheme_' . esc_attr( $coala_footer_scheme );
}
?>
				">
	<?php

	// Footer widgets area
	get_template_part( apply_filters( 'coala_filter_get_template_part', 'templates/footer-widgets' ) );

	// Logo
	get_template_part( apply_filters( 'coala_filter_get_template_part', 'templates/footer-logo' ) );

	// Socials
	get_template_part( apply_filters( 'coala_filter_get_template_part', 'templates/footer-socials' ) );

	// Copyright area
	get_template_part( apply_filters( 'coala_filter_get_template_part', 'templates/footer-copyright' ) );

	?>
</footer><!-- /.footer_wrap -->
