<?php
/**
 * The custom template to display the content
 *
 * Used for index/archive/search.
 *
 * @package COALA
 * @since COALA 1.0.50
 */

$coala_template_args = get_query_var( 'coala_template_args' );
if ( is_array( $coala_template_args ) ) {
	$coala_columns    = empty( $coala_template_args['columns'] ) ? 2 : max( 1, $coala_template_args['columns'] );
	$coala_blog_style = array( $coala_template_args['type'], $coala_columns );
} else {
	$coala_blog_style = explode( '_', coala_get_theme_option( 'blog_style' ) );
	$coala_columns    = empty( $coala_blog_style[1] ) ? 2 : max( 1, $coala_blog_style[1] );
}
$coala_blog_id       = coala_get_custom_blog_id( join( '_', $coala_blog_style ) );
$coala_blog_style[0] = str_replace( 'blog-custom-', '', $coala_blog_style[0] );
$coala_expanded      = ! coala_sidebar_present() && coala_get_theme_option( 'expand_content' ) == 'expand';
$coala_components    = ! empty( $coala_template_args['meta_parts'] )
							? ( is_array( $coala_template_args['meta_parts'] )
								? join( ',', $coala_template_args['meta_parts'] )
								: $coala_template_args['meta_parts']
								)
							: coala_array_get_keys_by_value( coala_get_theme_option( 'meta_parts' ) );
$coala_post_format   = get_post_format();
$coala_post_format   = empty( $coala_post_format ) ? 'standard' : str_replace( 'post-format-', '', $coala_post_format );

$coala_blog_meta     = coala_get_custom_layout_meta( $coala_blog_id );
$coala_custom_style  = ! empty( $coala_blog_meta['scripts_required'] ) ? $coala_blog_meta['scripts_required'] : 'none';

if ( ! empty( $coala_template_args['slider'] ) || $coala_columns > 1 || ! coala_is_off( $coala_custom_style ) ) {
	?><div class="
		<?php
		if ( ! empty( $coala_template_args['slider'] ) ) {
			echo 'slider-slide swiper-slide';
		} else {
			echo esc_attr( ( coala_is_off( $coala_custom_style ) ? 'column' : sprintf( '%1$s_item %1$s_item', $coala_custom_style ) ) . "-1_{$coala_columns}" );
		}
		?>
	">
	<?php
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
			'post_item post_item_container post_format_' . esc_attr( $coala_post_format )
					. ' post_layout_custom post_layout_custom_' . esc_attr( $coala_columns )
					. ' post_layout_' . esc_attr( $coala_blog_style[0] )
					. ' post_layout_' . esc_attr( $coala_blog_style[0] ) . '_' . esc_attr( $coala_columns )
					. ( ! coala_is_off( $coala_custom_style )
						? ' post_layout_' . esc_attr( $coala_custom_style )
							. ' post_layout_' . esc_attr( $coala_custom_style ) . '_' . esc_attr( $coala_columns )
						: ''
						)
		);
	coala_add_blog_animation( $coala_template_args );
	?>
>
	<?php
	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}
	// Custom layout
	do_action( 'coala_action_show_layout', $coala_blog_id, get_the_ID() );
	?>
</article><?php
if ( ! empty( $coala_template_args['slider'] ) || $coala_columns > 1 || ! coala_is_off( $coala_custom_style ) ) {
	?></div><?php
	// Need opening PHP-tag above just after </div>, because <div> is a inline-block element (used as column)!
}
