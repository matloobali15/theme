<?php
/**
 * The template to display Admin notices
 *
 * @package COALA
 * @since COALA 1.0.1
 */

$coala_theme_slug = get_option( 'template' );
$coala_theme_obj  = wp_get_theme( $coala_theme_slug );
?>
<div class="coala_admin_notice coala_welcome_notice notice notice-info is-dismissible" data-notice="admin">
	<?php
	// Theme image
	$coala_theme_img = coala_get_file_url( 'screenshot.jpg' );
	if ( '' != $coala_theme_img ) {
		?>
		<div class="coala_notice_image"><img src="<?php echo esc_url( $coala_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'coala' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="coala_notice_title">
		<?php
		echo esc_html(
			sprintf(
				// Translators: Add theme name and version to the 'Welcome' message
				__( 'Welcome to %1$s v.%2$s', 'coala' ),
				$coala_theme_obj->get( 'Name' ) . ( COALA_THEME_FREE ? ' ' . __( 'Free', 'coala' ) : '' ),
				$coala_theme_obj->get( 'Version' )
			)
		);
		?>
	</h3>
	<?php

	// Description
	?>
	<div class="coala_notice_text">
		<p class="coala_notice_text_description">
			<?php
			echo str_replace( '. ', '.<br>', wp_kses_data( $coala_theme_obj->description ) );
			?>
		</p>
		<p class="coala_notice_text_info">
			<?php
			echo wp_kses_data( __( 'Attention! Plugin "ThemeREX Addons" is required! Please, install and activate it!', 'coala' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="coala_notice_buttons">
		<?php
		// Link to the page 'About Theme'
		?>
		<a href="<?php echo esc_url( admin_url() . 'themes.php?page=coala_about' ); ?>" class="button button-primary"><i class="dashicons dashicons-nametag"></i> 
			<?php
			echo esc_html__( 'Install plugin "ThemeREX Addons"', 'coala' );
			?>
		</a>
	</div>
</div>
