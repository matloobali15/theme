<?php
/**
 * The template to display the background video in the header
 *
 * @package COALA
 * @since COALA 1.0.14
 */
$coala_header_video = coala_get_header_video();
$coala_embed_video  = '';
if ( ! empty( $coala_header_video ) && ! coala_is_from_uploads( $coala_header_video ) ) {
	if ( coala_is_youtube_url( $coala_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $coala_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php coala_show_layout( coala_get_embed_video( $coala_header_video ) ); ?></div>
		<?php
	}
}
