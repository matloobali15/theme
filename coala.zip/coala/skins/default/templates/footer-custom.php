<?php
/**
 * The template to display default site footer
 *
 * @package COALA
 * @since COALA 1.0.10
 */

$coala_footer_id = coala_get_custom_footer_id();
$coala_footer_meta = get_post_meta( $coala_footer_id, 'trx_addons_options', true );
if ( ! empty( $coala_footer_meta['margin'] ) ) {
	coala_add_inline_css( sprintf( '.page_content_wrap{padding-bottom:%s}', esc_attr( coala_prepare_css_value( $coala_footer_meta['margin'] ) ) ) );
}
?>
<footer class="footer_wrap footer_custom footer_custom_<?php echo esc_attr( $coala_footer_id ); ?> footer_custom_<?php echo esc_attr( sanitize_title( get_the_title( $coala_footer_id ) ) ); ?>
						<?php
						$coala_footer_scheme = coala_get_theme_option( 'footer_scheme' );
						if ( ! empty( $coala_footer_scheme ) && ! coala_is_inherit( $coala_footer_scheme  ) ) {
							echo ' scheme_' . esc_attr( $coala_footer_scheme );
						}
						?>
						">
	<?php
	// Custom footer's layout
	do_action( 'coala_action_show_layout', $coala_footer_id );
	?>
</footer><!-- /.footer_wrap -->
