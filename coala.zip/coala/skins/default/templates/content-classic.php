<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package COALA
 * @since COALA 1.0
 */

$coala_template_args = get_query_var( 'coala_template_args' );

if ( is_array( $coala_template_args ) ) {
	$coala_columns    = empty( $coala_template_args['columns'] ) ? 2 : max( 1, $coala_template_args['columns'] );
	$coala_blog_style = array( $coala_template_args['type'], $coala_columns );
    $coala_columns_class = coala_get_column_class( 1, $coala_columns, ! empty( $coala_template_args['columns_tablet']) ? $coala_template_args['columns_tablet'] : '', ! empty($coala_template_args['columns_mobile']) ? $coala_template_args['columns_mobile'] : '' );
} else {
	$coala_blog_style = explode( '_', coala_get_theme_option( 'blog_style' ) );
	$coala_columns    = empty( $coala_blog_style[1] ) ? 2 : max( 1, $coala_blog_style[1] );
    $coala_columns_class = coala_get_column_class( 1, $coala_columns );
}
$coala_expanded   = ! coala_sidebar_present() && coala_get_theme_option( 'expand_content' ) == 'expand';

$coala_post_format = get_post_format();
$coala_post_format = empty( $coala_post_format ) ? 'standard' : str_replace( 'post-format-', '', $coala_post_format );

?><div class="<?php
	if ( ! empty( $coala_template_args['slider'] ) ) {
		echo ' slider-slide swiper-slide';
	} else {
		echo ( coala_is_blog_style_use_masonry( $coala_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $coala_columns ) : esc_attr( $coala_columns_class ) );
	}
?>"><article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $coala_post_format )
				. ' post_layout_classic post_layout_classic_' . esc_attr( $coala_columns )
				. ' post_layout_' . esc_attr( $coala_blog_style[0] )
				. ' post_layout_' . esc_attr( $coala_blog_style[0] ) . '_' . esc_attr( $coala_columns )
	);
	coala_add_blog_animation( $coala_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$coala_hover      = ! empty( $coala_template_args['hover'] ) && ! coala_is_inherit( $coala_template_args['hover'] )
							? $coala_template_args['hover']
							: coala_get_theme_option( 'image_hover' );

	$coala_components = ! empty( $coala_template_args['meta_parts'] )
							? ( is_array( $coala_template_args['meta_parts'] )
								? $coala_template_args['meta_parts']
								: explode( ',', $coala_template_args['meta_parts'] )
								)
							: coala_array_get_keys_by_value( coala_get_theme_option( 'meta_parts' ) );

	coala_show_post_featured( apply_filters( 'coala_filter_args_featured',
		array(
			'thumb_size' => ! empty( $coala_template_args['thumb_size'] )
				? $coala_template_args['thumb_size']
				: coala_get_thumb_size(
					'classic' == $coala_blog_style[0]
						? ( strpos( coala_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $coala_columns > 2 ? 'big' : 'huge' )
								: ( $coala_columns > 2
									? ( $coala_expanded ? 'square' : 'square' )
									: ($coala_columns > 1 ? 'square' : ( $coala_expanded ? 'huge' : 'big' ))
									)
							)
						: ( strpos( coala_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $coala_columns > 2 ? 'masonry-big' : 'full' )
								: ($coala_columns === 1 ? ( $coala_expanded ? 'huge' : 'big' ) : ( $coala_columns <= 2 && $coala_expanded ? 'masonry-big' : 'masonry' ))
							)
			),
			'hover'      => $coala_hover,
			'meta_parts' => $coala_components,
			'no_links'   => ! empty( $coala_template_args['no_links'] ),
        ),
        'content-classic',
        $coala_template_args
    ) );

	// Title and post meta
	$coala_show_title = get_the_title() != '';
	$coala_show_meta  = count( $coala_components ) > 0 && ! in_array( $coala_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );

	if ( $coala_show_title ) {
		?>
		<div class="post_header entry-header">
			<?php

			// Post meta
			if ( apply_filters( 'coala_filter_show_blog_meta', $coala_show_meta, $coala_components, 'classic' ) ) {
				if ( count( $coala_components ) > 0 ) {
					do_action( 'coala_action_before_post_meta' );
					coala_show_post_meta(
						apply_filters(
							'coala_filter_post_meta_args', array(
							'components' => join( ',', $coala_components ),
							'seo'        => false,
							'echo'       => true,
						), $coala_blog_style[0], $coala_columns
						)
					);
					do_action( 'coala_action_after_post_meta' );
				}
			}

			// Post title
			if ( apply_filters( 'coala_filter_show_blog_title', true, 'classic' ) ) {
				do_action( 'coala_action_before_post_title' );
				if ( empty( $coala_template_args['no_links'] ) ) {
					the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );
				} else {
					the_title( '<h4 class="post_title entry-title">', '</h4>' );
				}
				do_action( 'coala_action_after_post_title' );
			}

			if( !in_array( $coala_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
				// More button
				if ( apply_filters( 'coala_filter_show_blog_readmore', ! $coala_show_title || ! empty( $coala_template_args['more_button'] ), 'classic' ) ) {
					if ( empty( $coala_template_args['no_links'] ) ) {
						do_action( 'coala_action_before_post_readmore' );
						coala_show_post_more_link( $coala_template_args, '<div class="more-wrap">', '</div>' );
						do_action( 'coala_action_after_post_readmore' );
					}
				}
			}
			?>
		</div><!-- .entry-header -->
		<?php
	}

	// Post content
	if( in_array( $coala_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
		ob_start();
		if (apply_filters('coala_filter_show_blog_excerpt', empty($coala_template_args['hide_excerpt']) && coala_get_theme_option('excerpt_length') > 0, 'classic')) {
			coala_show_post_content($coala_template_args, '<div class="post_content_inner">', '</div>');
		}
		// More button
		if(! empty( $coala_template_args['more_button'] )) {
			if ( empty( $coala_template_args['no_links'] ) ) {
				do_action( 'coala_action_before_post_readmore' );
				coala_show_post_more_link( $coala_template_args, '<div class="more-wrap">', '</div>' );
				do_action( 'coala_action_after_post_readmore' );
			}
		}
		$coala_content = ob_get_contents();
		ob_end_clean();
		coala_show_layout($coala_content, '<div class="post_content entry-content">', '</div><!-- .entry-content -->');
	}
	?>

</article></div><?php
// Need opening PHP-tag above, because <div> is a inline-block element (used as column)!
